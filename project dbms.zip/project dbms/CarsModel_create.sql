-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2021-12-18 03:58:51.966

-- tables
-- Table: CarData
CREATE TABLE CarData (
    CarName Varchar  NOT NULL,
    CarPrice int  NOT NULL,
    Features Varchar  NOT NULL,
    CarID int  NOT NULL,
    CONSTRAINT CarData_pk PRIMARY KEY  (CarID)
);

-- Table: CarOrganization
CREATE TABLE CarOrganization (
    EmpName Varchar  NOT NULL,
    EmpNo int  NOT NULL,
    Location Varchar  NOT NULL,
    EmpAddr Varchar  NOT NULL,
    CONSTRAINT CarOrganization_pk PRIMARY KEY  (EmpNo)
);

-- Table: Customer
CREATE TABLE Customer (
    CustomerName Varchar  NOT NULL,
    CustomerId int  NOT NULL,
    CustomerAddr Varchar  NOT NULL,
    CustomerMobileNo Varchar  NOT NULL,
    CONSTRAINT Customer_pk PRIMARY KEY  (CustomerId)
);

-- Table: Emp_org
CREATE TABLE Emp_org (
    OrgId int  NOT NULL,
    Contact int  NOT NULL,
    Id int  NOT NULL,
    CarOrganization_EmpNo int  NOT NULL,
    CONSTRAINT Emp_org_pk PRIMARY KEY  (Id)
);

-- Table: OrderStatus
CREATE TABLE OrderStatus (
    OrderName Varchar  NOT NULL,
    OrderId int  NOT NULL,
    OrderStatus Varchar  NOT NULL,
    CONSTRAINT OrderStatus_pk PRIMARY KEY  (OrderId)
);

-- Table: Orders
CREATE TABLE Orders (
    OrganizationId int  NOT NULL,
    CustomerId int  NOT NULL,
    DeliveryStatus int  NOT NULL,
    TotalOrders int  NOT NULL,
    OrderStatus_OrderId int  NOT NULL,
    CarData_CarID int  NOT NULL,
    CONSTRAINT Orders_pk PRIMARY KEY  (OrganizationId)
);

-- foreign keys
-- Reference: Emp_org_CarOrganization (table: Emp_org)
ALTER TABLE Emp_org ADD CONSTRAINT Emp_org_CarOrganization
    FOREIGN KEY (CarOrganization_EmpNo)
    REFERENCES CarOrganization (EmpNo);

-- Reference: Orders_CarData (table: Orders)
ALTER TABLE Orders ADD CONSTRAINT Orders_CarData
    FOREIGN KEY (CarData_CarID)
    REFERENCES CarData (CarID);

-- Reference: Orders_OrderStatus (table: Orders)
ALTER TABLE Orders ADD CONSTRAINT Orders_OrderStatus
    FOREIGN KEY (OrderStatus_OrderId)
    REFERENCES OrderStatus (OrderId);

-- End of file.

